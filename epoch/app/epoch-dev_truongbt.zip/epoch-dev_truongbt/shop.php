<?php
// require_once 'includes/country.inc.php';
require_once 'Mobile_Detect.php';
?>

<?php
$detect = new Mobile_Detect();
$filename = '';
$pc = false;

if ($detect->isMobile() && !$detect->isTablet()){
    $filename = 'mobile/shop.php';
} else {
    $filename = 'pc/shop.php';
    $pc = true;
}

$title = 'シルバニア森のキッチン ｜ Sylvanian Families';
$desc = 'シルバニア森のキッチンの公式サイトです。シルバニアファミリーのレストラン　シルバニア森のキッチンは、おいしいごはんに、たのしいショー、シルバニアファミリーのグッズが買える楽しいレストランで';
$keyword = 'シルバニアファミリー,シルバニア,Sylvanian Families,レストラン,森のキッチン,おもちゃ,バースデープラン';

?>

<?php include('header.php'); ?>

<?php include($filename); ?>

<?php include('footer.php'); ?>