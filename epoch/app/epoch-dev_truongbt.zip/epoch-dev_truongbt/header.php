<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="content-style-type" content="text/css"/>
    <meta http-equiv="content-script-type" content="text/javascript"/>
    <meta name="viewport" content="initial-scale=1.0,width=device-width,user-scalable=yes,minimum-scale=1.0,maximum-scale=2.0"/>
    <meta name="robots" content="index,follow" />
    <meta name="revisit_after" content="7 days" />
    <meta name="keywords" content="<?php echo $keyword ?>">
    <meta name="description" content="<?php echo $desc ?>" />
    <meta property="og:title" content="シルバニア森のキッチン公式サイト" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="http://sylvanian-families.jp/world_view/" />
    <meta property="og:image" content="/includes_gl/img/common/img_fb.jpg" />
    <meta property="og:site_name" content="シルバニアファミリー公式サイト" />
    <meta property="og:locale" content="ja_JP" />
    <meta property="fb:app_id" content="580609391991136" />
    <!-- InstanceBeginEditable name="meta" -->
    <!-- InstanceEndEditable -->
    <title><?php echo $title ?></title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <!-- Bootstrap JS -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.ui.min.js"></script>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/vnd.microsoft.icon"/>
    <link rel="icon" href="favicon.ico" type="image/vnd.microsoft.icon"/>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if gt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>

<?php
$detect = new Mobile_Detect();
$class = '';

if ($detect->isMobile() && !$detect->isTablet()){
    $class = '';
} elseif ($detect->isTablet()){
    $class = 'only_ipad';
} else {
    $class = 'only_pc';
}

?>

<div class="wrap_container <?php echo $class ?>" id="acv-content">
    <?php if ($pc) : ?>
        <div class="logo-top-wrapper">
            <div class="container container_pc">
                <div class="logo-top col-xs-10 col-xs-offset-1">
                    <img src="images/maintop_kitchen.png" alt="" class="img-responsive lazy">
                </div>
            </div>
        </div>
        <div class="pc-top-menu-wrapper">
            <div class="top-menu-container">
                <div class="container container_pc">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-4 col-xs-4 border-right-img nav_pc">
                                <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/"> <img
                                        src="images/menu_1.png"
                                        alt=""
                                        class="opacity_img img-responsive lazy col-xs-12 delpadding "></a>
                            </div>
                            <div class="col-lg-4 col-xs-4 border-right-img nav_pc">
                                <a href="http://sylvanian-families.jp/shop/kitchen/laketown/">
                                    <img src="images/menu_2.png" alt=""
                                         class="opacity_img img-responsive lazy col-xs-12 delpadding "></a>
                            </div>
                            <div class="col-lg-4 col-xs-4 nav_pc">
                                <a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/"> <img
                                        src="images/menu_3.png"
                                        alt=""
                                        class="opacity_img img-responsive lazy col-xs-12 delpadding "></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="m-logo-top-wrapper">
            <img src="images/m/logo-header.png" alt="" class="img-responsive">
        </div>
        <div class="btn-group m-btn-menu " role="group">
            <div class="m-menus-wrapper">
                <div class="m-menu">
                    <a type="button " id="m-btn-menu" class="btn-nav-custom m-nav-border" data-toggle="dropdown" aria-expanded="false">
                        店舗をお選びください
                        <span class="img-heart"></span>
                    </a>
                </div>
            </div>
            <ul class="dropdown-menu m-menus-custom" role="menu">
                <li><a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/">横浜ワールドポーターズ店</a></li>
                <li><a href="http://sylvanian-families.jp/shop/kitchen/laketown/">レイクタウンアウトレット店</a></li>
                <li><a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/">ららぼーとTOKYO-BAY店</a></li>
            </ul>
        </div>
    <?php endif; ?>
