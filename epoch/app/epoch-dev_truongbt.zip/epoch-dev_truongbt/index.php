<?php require_once 'includes/country.inc.php';
require_once 'Mobile_Detect.php';
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="content-style-type" content="text/css"/>
    <meta http-equiv="content-script-type" content="text/javascript"/>
    <meta name="viewport" content="initial-scale=1.0,width=device-width,user-scalable=yes,minimum-scale=1.0,maximum-scale=2.0"/>
    <meta name="robots" content="index,follow" />
    <meta name="revisit_after" content="7 days" />
    <meta name="keywords" content="シルバニアファミリー,シルバニア,Sylvanian Families,レストラン,森のキッチン,おもちゃ,バースデープラン">
    <meta name="description" content="シルバニア森のキッチンの公式サイトです。シルバニアファミリーのレストラン　シルバニア森のキッチンは、おいしいごはんに、たのしいショー、シルバニアファミリーのグッズが買える楽しいレストランで" />
    <meta property="og:title" content="シルバニア森のキッチン公式サイト" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="http://sylvanian-families.jp/world_view/" />
    <meta property="og:image" content="/includes_gl/img/common/img_fb.jpg" />
    <meta property="og:site_name" content="シルバニアファミリー公式サイト" />
    <meta property="og:locale" content="ja_JP" />
    <meta property="fb:app_id" content="580609391991136" />
    <!-- InstanceBeginEditable name="meta" -->
    <!-- InstanceEndEditable -->
    <title>シルバニア森のキッチン ｜ Sylvanian Families</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">
    <!-- Bootstrap JS -->
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.ui.min.js"></script>
    <link rel="stylesheet" href="css/style_home.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/vnd.microsoft.icon"/>
    <link rel="icon" href="favicon.ico" type="image/vnd.microsoft.icon"/>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if gt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>

<?php
$detect = new Mobile_Detect();
$filename = '';
$pc = false;
$ipad = false;
if ($detect->isMobile() && !$detect->isTablet()){
    $filename = 'index_mobile.php';
}else if($detect->isTablet()){
    $pc = false;
    $ipad = true;
    $filename = 'index_pc.php';
}else{
    $pc = true;
    $filename = 'index_pc.php';
}
?>

<div class="wrap_container <?php echo ($pc ? 'only_pc' : ($ipad ? 'only_ipad' : '')) ?>" id="acv-content">
    <?php include($filename); ?>
    <script type="text/javascript" src="js/jquery.lazy.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
</div>

<?php include('includes/analyticstracking.php'); ?>

</body>
</html>