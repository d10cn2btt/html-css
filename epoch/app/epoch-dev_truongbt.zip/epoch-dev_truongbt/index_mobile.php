<style>
    .none_pc{
        display: inherit !important;
    }
</style>
<div class="none_pc m-header-logo">
    <img src="images/m/logo-header.png" alt="" class="img-responsive width_mobile">
</div>
<div class="none_pc">
    <div class="btn-group button_nav_custom_1" role="group" aria-label="...">
        <div class="btn-group button_nav_custom_1 " role="group">
            <div class="wrap_menu_parent">
                <div class="wrap_menu">
                    <a type="button " id="ddl" class="button_nav_custom border_nav_mobile" data-toggle="dropdown"
                       aria-expanded="false">
                        店舗をお選びください
                        <span class="caret_custom"></span>
                    </a>
                </div>
            </div>
            <ul class="dropdown-menu ul_custom" role="menu">
                <li><a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/">横浜ワールドポーターズ店</a></li>
                <li><a href="http://sylvanian-families.jp/shop/kitchen/laketown/">レイクタウンアウトレット店</a></li>
                <li><a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/">ららぼーとTOKYO-BAY店</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="content-canvas none_pc">
    <div id="carousel-example-generic1" class="wow fadeIn carousel slide" data-ride="carousel">
        <ol class="carousel-indicators carousel-indicators_mobile">
            <li data-target="#carousel-example-generic1" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic1" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic1" data-slide-to="2"></li>
            <li data-target="#carousel-example-generic1" data-slide-to="3"></li>
        </ol>
        <div class="clear_both"></div>
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="images/slider/slide_mobile_2.jpg"
                     alt="シルバニア森のキッチンはシルバニアファミリーの仲間たちと会える楽しいレストランです！" class="lazy">
            </div>
            <div class="item ">
                <img src="images/slider/slide_mobile_1.jpg"
                     alt="バースデープランで特別な思い出を作りましょう！" class="lazy">
            </div>

            <div class="item">
                <img src="images/slider/slide_mobile_3.jpg" alt="家族みんなが大満足の大人気ブッフェ！" class="lazy">
            </div>
            <div class="item">
                <img src="images/slider/slide_mobile_4.jpg" alt="シルバニア森のキッチンではショコラウサギシェフが出迎えてくれます！" class="lazy">
            </div>
        </div>
        <!-- Controls -->
        <a class="left carousel-control none_mobile" href="#carousel-example-generic" role="button"
           data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left bg_nav_slide_left" aria-hidden="true">

                </span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control none_mobile" href="#carousel-example-generic" role="button"
           data-slide="next">
            <span class="glyphicon glyphicon-chevron-right bg_nav_slide_right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>
    <!-- end top slide -->
</div>

<!--content for mobile    -->
<div class="none_pc">
    <div class="container">
        <div class="content_bottom_mobile_1">
            <a href="#bottom_mobile_1">
                WEB順番予約はこちら
                <span class="btn_down_2_mobile"> </span>
            </a>
        </div>
        <div class="title_content_2_mobile" id="bottom_mobile">
            <div class="title_content_header_mobile">シルバニア森のキッチンについて</div>
            <div class="line_dot_mobile"></div>
            <div class="line_mobile">シルバニアファミリーのレストランです！<br/>
                おいしいごはんに、楽しいショー、<br/>
                シルバニアグッズも買えるすてきなお店です。
            </div>
            <div class="btn_up">

            </div>
        </div>

        <div class="col-sm-12 col-xs-12 content_mobile">
            <img src="images/m/title_content_1.png" class="img-responsive center-block m-title">
            <img src="images/m/content_1.jpg" alt="シルバニア村の仲間たちと一緒に写真撮影！" class="width_mobile img-responsive lazy">

            <div class="content_text_mobile">シルバニアファミリーのなかまがお席まで遊びに来ます！<br/>
                あくしゅをしたり、写真をとったり、なかよしくしてくださいね。<br/>
                店内には人形や小物がたくさん！見ているだけでワクワクしてきます。
            </div>
        </div>
        <div class="col-sm-12 col-xs-12 content_mobile">
            <img src="images/m/title_content_2.png" class="img-responsive center-block m-title">
            <img src="images/m/content_2.jpg" alt="バースデープランのショコラウサギシェフ特製の特別なケーキ！" class="width_mobile img-responsive lazy">

            <div class="bg_img_3_mobile"><a
                    href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/birthday.php">バースデーセットの詳細はこちら</a>
            </div>
            <div class="content_text_mobile">シルバニアファミリーのなかまがお祝いしてくれるバースデープランをご用意しています。<br/>
                ケーキのろうそくを吹き消したあとは、プレゼントをもらって記念撮影。<br/>
                大切な記念日をシルバニアファミリーのなかまと楽しくすごしましょう！
            </div>
        </div>
        <div class="col-sm-12 col-xs-12 content_mobile">
            <img src="images/m/title_content_3.png" class="img-responsive center-block m-title">
            <img src="images/m/buffer-3.png" alt="家族みんなで好きなお料理をお腹いっぱい食べましょう！" class="width_mobile img-responsive lazy">

            <div class="content_text_mobile">ショコラウサギシェフのおいしい料理をおなかいっぱい楽しめるブッフェ形式です。<br/>
                自分たちで作れるわたがしはお子様たちに大人気！
            </div>
        </div>
        <div class="col-sm-12 col-xs-12 content_mobile">
            <img src="images/m/title_content_4.png" alt="シルバニアファミリーの大きなジオラマを展示しています！"
                 class="img-responsive center-block m-title">
            <img src="images/m/content_4.jpg" alt="" class="width_mobile img-responsive lazy">

            <div class="content_text_mobile">
                シルバニアファミリーの雑貨や海外で販売されている商品など特別なアイテムがたくさん。<br/>
                大きなジオラマも展示しています。
            </div>

        </div>
        <div class="col-sm-12 col-xs-12 content_mobile_no_wrap" style="margin-bottom: 0px">
            <a href="http://sylvanian-families.jp/fanclub/info/members_card.php" target="_blank">
                <img src="images/banner-fanclub-membercard.png"
                     alt="シルバニアファミリーのお店で割引価格でお買い物ができるプレミアム会員メンバーズカードの特典はこちらから！"
                     class="width_mobile img-responsive lazy">
            </a>
        </div>
        <div class="col-sm-12 col-xs-12 content_mobile_no_wrap">
            <a href="http://sylvanian-families.jp/play/kitchen/" target="_blank">
                <img src="images/banner-kitchen.png"
                     alt="シルバニア森のキッチンのシェフがショコラウサギのお父さんになったよ！森のキッチンミニストーリーはこちら！"
                     class="width_mobile img-responsive lazy">
            </a>
        </div>
    </div>
</div>
<div class="line none_pc line_mobile line_m"></div>

<div class="mt20px none_pc fix_horizontal_mobile">
    <img src="images/c6.png" alt="" class="width_mobile img-responsive auto mb15im lazy">
</div>
<div class="container none_pc " id="bottom_mobile_1">
    <div class="col-sm-12 col-xs-12 content_mobile link-item">
        <div class="col-md-7 col-xs-7 item-inner">
            <div class="col-xs-8 item-border-right">
                <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/" style="">
                    <img src="images/text1.png" alt="" class="img-responsive">
                </a>
            </div>
            <div class="col-xs-4 text-pink">
                <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/">
                    <img src="images/text-pink.png" alt="" class="img-responsive">
                </a>
            </div>
        </div>
        <div class="col-md-5 col-xs-5 btn-link-green">
            <div class="rounder-green">
                <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/reserve.php">
                    WEB順番予約はこちら
                </a>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-xs-12 content_mobile link-item">
        <div class="col-md-7 col-xs-7 item-inner">
            <div class="col-xs-8 item-border-right">
                <a href="http://sylvanian-families.jp/shop/kitchen/laketown/" style="">
                    <img src="images/text2.png" alt="" class="img-responsive">
                </a>
            </div>
            <div class="col-xs-4 text-pink">
                <a href="http://sylvanian-families.jp/shop/kitchen/laketown/">
                    <img src="images/text-pink.png" alt="" class="img-responsive">
                </a>
            </div>
        </div>
        <div class="col-md-5 col-xs-5 btn-link-green">
            <div class="rounder-green">
                <a href="http://sylvanian-families.jp/shop/kitchen/laketown/reserve.php">
                    WEB順番予約はこちら
                </a>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-xs-12 content_mobile link-item">
        <div class="col-md-7 col-xs-7 item-inner">
            <div class="col-xs-8 item-border-right">
                <a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/" style="">
                    <img src="images/text3.png" alt="" class="img-responsive">
                </a>
            </div>
            <div class="col-xs-4 text-pink">
                <a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/">
                    <img src="images/text-pink.png" alt="" class="img-responsive">
                </a>
            </div>
        </div>
        <div class="col-md-5 col-xs-5 btn-link-green">
            <div class="rounder-green">
                <a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/reserve.php">
                    WEB順番予約はこちら
                </a>
            </div>
        </div>
    </div>
</div>
<div class="none_pc footer">
    <div class="line line_mobile"></div>
    <div class=" ">
        <ul class="icon_footer_mobile ">
            <li>
                <a href="https://www.facebook.com/SylvanianFamilies.jp" target="_blank">
                    <img src="images/footer_icon_1.png" alt="" class="lazy">
                </a>
            </li>
            <li>
                <a href="https://twitter.com/SF_PHOTO2013" target="_blank">
                    <img src="images/footer_icon_2.png" alt="" class="lazy">
                </a>
            </li>
            <li>
                <a href="https://instagram.com/sylvanianfamilies_official/" target="_blank">
                    <img src="images/footer_icon_3.png" alt="" class="lazy">
                </a>
            </li>
        </ul>
        <a href="http://sylvanian-families.jp/?page=home" target="_blank">
            <img src="images/logo.png" alt="" class="img-responsive auto lazy">
        </a>

        <div class="title-footer">
            <div class="tf-1-mobile center bold">
                | <a href="http://sylvanian-families.jp/support/policy.php">プライバシーポリシー</a> |
            </div>
            <div class="tf-2-mobile center bold">© EPOCH</div>
        </div>
    </div>
</div>
<a href="#to_top_mobile" class="totop_m" style="display: none"></a>