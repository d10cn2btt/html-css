<?php
// Refjpe direct access
if(basename($_SERVER["PHP_SELF"])=="country.inc.php") { exit; }

define("COUNTRY_ID"  , 42);	  		//日本
define("LANGUAGE_ID" , 23);			//日本語
define("LANG_NUM"    , 1);			
define("LOCALE"      , "ja_JP.UTF-8");	    //日本
define("TIMEZONE"    ,  "Asia/Tokyo");	//東京


// 【日本のみ】CDN負荷軽減処理用（他の国は必要ない）
//$cdn_rateSakura = 0.7;  // 0->2 is 100%,   1->1 is 100%,   0.2->1 is 20% and 2 is 80%
//$cdn_rand_max   = 10000;
//$cdn_randVal    = mt_rand(1,$cdn_rand_max);
$cdn_select     = 1;//($cdn_rand_max*$cdn_rateSakura >= $cdn_randVal)? 1 : 2;
// 【日本のみ】以上


if (isset($_SERVER['HTTPS'])) {
	define("DOMAIN_NAME", "sylvanianfamilies.net");
} else {
    define("DOMAIN_NAME", "sylvanian-families.jp");
}

define("ROOT"       , "../");

if (strstr($_SERVER["SERVER_NAME"], "test")) {
	define("HTML_PATH"   , "http://test.sylvanian-families.jp/");
	define("SSL_URL"     , "https://test.sylvanianfamilies.net/jp/");
	define("URL_DIR"     , "/var/www/vhosts/test.sylvanianfamilies.biz/jp/");
	if($_SERVER['HTTPS']=='on'){
		define("CDN_PATH"    , "https://test.sylvanianfamilies.net");
	}else{
		define("CDN_PATH"    , "http://test.cdn-org.sylvanianfamilies.net");
	}
	define("CDN_PATH_CUR", CDN_PATH."/jp");
	
	define("HTML_PATH_EC_DOMAIN"  , "shop.sylvanian-families.jp");
	define("HTML_PATH_EC"         , "http://".HTML_PATH_EC_DOMAIN."/stg/shop/");
	define("HTML_PATH_EC_SECURE"  , "https://".HTML_PATH_EC_DOMAIN."/stg/shop/");

} else {
	define("HTML_PATH"   , "http://sylvanian-families.jp/");
	define("SSL_URL"     , "https://sylvanianfamilies.net/jp/");
	define("URL_DIR"     , "/var/www/vhosts/sylvanianfamilies.biz/jp/");
	if($_SERVER['HTTPS']=='on'){
		define("CDN_PATH"    , "https://sylvanianfamilies.net");
	}else{
		if($cdn_select==1){  // サクラ直接
			define("CDN_PATH"    , "http://cdn-org.sylvanianfamilies.net");
		} else {			 // CDN
			define("CDN_PATH"    , "http://cdn.sylvanianfamilies.net");
		}
	}
	define("CDN_PATH_CUR", CDN_PATH."/jp");
	
	define("HTML_PATH_EC_DOMAIN"  , "shop.sylvanian-families.jp");
	define("HTML_PATH_EC"         , "http://".HTML_PATH_EC_DOMAIN."/");
	define("HTML_PATH_EC_SECURE"  , "https://".HTML_PATH_EC_DOMAIN."/");
	
}


// Maintenance Setting
define("MAINTENANCE", true);	//メンテナンス切り替えを有効にするかどうか
$Maintenance_Pages = array(     //メンテナンスするページ
"fanclub/index.php",
"fanclub/info/index.php",
"fanclub/info/index_mb.php",
"fanclub/howto/index.php",
"fanclub/howtowebmag/index.php",
"fanclub/howtoupgrade/index.php",
"fanclub/change/index.php",
"fanclub/change/top.php",
"fanclub/change/change_password.php",
"fanclub/change/change_family.php",
"fanclub/change/change_email.php",
"fanclub/change/change_topremium.php",
"fanclub/change/change_cancel.php",
"fanclub/change/change_info.php",
"fanclub/member/index.php",
"fanclub/renew/index.php",
"fanclub/renew/renew_membership.php",
"fanclub/regist/regist.php"
);
$Maintenance_TmpPage = HTML_PATH."maintenance_fanclub.php";	//メンテナンス中の表示画面
$Maintenance_Date = array(	    // サーバー時間でのメンテナンス開始、終了日時
	"start" => "2016-04-12 02:00:00",
	"end" =>  "2016-04-12 04:00:00"
);

// Mail Setting
define("MAIL_CONTACT_TO", "");
define("MAIL_CONTACT_FROM", "jp-news@sylvanianfamilies.net");
define("MAIL_CONTACT_FROM_NAME", "シルバニアファミリーファンクラブ");
define("MAIL_CLUB_FROM", "jp-news@sylvanianfamilies.net");
define("MAIL_CLUB_FROM_NAME", "シルバニアファミリーファンクラブ");

define("ECARDS_FROM", "jp-news@sylvanianfamilies.net");
define("ECARDS_FROM_NAME", "シルバニアファミリーファンクラブ");


// LOG
define("CUSTOMER_LOG_PATH", URL_DIR."logs/customer.log");
define("CUSTOMER_NOTICE_LOG_PATH", URL_DIR."logs/customer_notice.log");
define("CUSTOMER_SERIOUS_LOG_PATH", URL_DIR."logs/customer_serious.log");
define("CUSTOMER_EXPIRE_LOG_PATH", URL_DIR."logs/customer_expire.log");
define("PAYMENT_LOG_PATH", URL_DIR."logs/payment.log");
define("PAYMENT_ECAPI_PATH", URL_DIR."logs/ecapi.log");

// Catalog Setting
define("CATALOG_DISPLAY_ENG", false);
define("CATALOG_LIST_W" , 180);
define("CATALOG_LIST_H" , 135);
define("CATALOG_RELATED_W" , 130);
define("CATALOG_RELATED_H" , 100);
define("CATALOG_DISPLAY_MANUAL", true);
define("CATALOG_DISPLAY_TPL", true);
define("CATALOG_TAX_RATE", 1.08);

// Shop List Setting
define("SHOP_LIMIT", 10);
define("SHOP_DISPLAY_ALL", false);

// Translation -------------------------------------------------- //
// Catalog
$Lang_Catalog= array(
   "home"		=> "ホーム",
   "catalog"	=> "商品カタログ",
   "price"		=> "メーカー希望小売価格 : ",
   "itemcode"	=> "アイテムコード : ",
   "featured"   => "ピックアップ",
   "related"	=> "関連商品",
   "new"		=> "New",
   "purchase"	=> "購入",
   "manual"		=> "マニュアルダウンロード",
   "release"	=> "発売日：",
);

$Lang_Catalog_Notice = array(
	"この写真はイメージです。 ",
	"お人形は含まれておりません。 ",
	"お人形以外の商品は別売りです。 ",
	"セット内容以外の人形・家具などは別売りです。 ",
	"壁・床などは含まれておりません。 ",
	"撮影用に一部小物などを使用しております。 ",
	"製品と写真は仕様が一部異なる場合があります。",
 );

// Shop
$Lang_Shop= array(
   "Enter"  => "住所・地域を入力してください",
   "Search" => "検索半径",
   "tel"	=> "電話番号 : ",
   "fax"	=> "Fax番号 : ",
   "email"	=> "Eメール : ",
   "notfound" => "店舗がみつかりません。"
);


// PREMIUM
define("PLAN_NAME_PREMIUM"        , "プレミアム会員");
define("PLAN_NAME_STANDARD"       , "ウェブ・メルマガ会員");

define('CHILD_AGE', '20');
define('CHILD_AGE_PREMIUM', '20');

define("PREMIUM_PRICE_FORMAT"     ,    0); // 小数点桁数
define("PREMIUM_PRICE_YEAR"       , 1500); //新規プレミアム登録料
define('PREMIUM_PRICE_YEAR_RENEW' , 1000); //プレミアム更新料
define("CONSUMPTION_TAX"          , 0.08);
define("PREMIUM_NOPAYMENT_EXPIRE" ,    5);

define("REGISTER_DISP_1"        , 'シルバニアファミリーファンクラブ');  // レジ表示
define("RECEIPTS_DISP_1"        , 'シルバニアファミリーファンクラブ　プレミアム会員年会費');  // レシート表示
define("RECEIPTS_DISP_11"       , 'お客様センター');	// 問い合わせ先
define("RECEIPTS_DISP_12"       , '03-4405-8086');	// 電話番号
define("RECEIPTS_DISP_13"       , '10:00-17:00');	// 問合せ受付時間


// Error Message (Fan Club)
define("ERR_WRONG_AIKOTOBA"     , "あいことばがちがうよ！");
define("ERR_EXIST_CHECK"        , "入力してください");
define("ERR_KANA_CHECK"         , "ひらがなを入力してください");
define("ERR_SELECT_CHECK"       , "選択してください");
define("ERR_EQUAL_CHECK"        , "一致しません");
define("ERR_NUM_CHECK"	        , "数値を入力してください");
define("ERR_LEN_CHECK"	        , "%d文字以内で入力してください");
define("ERR_SJIS_CHECK"	        , "使用できない文字が含まれています");
define("ERR_DATE_CHECK"         , "日付が正しくありません");
define("ERR_TEL_CHECK"          , "正しい電話番号をハイフン付きで入力してください");
define("ERR_EMAIL_CHECK"        , "正しいメールアドレスを入力してください");
define("ERR_EMAIL_EQUAL_CHECK"  , "確認用メールアドレスと異なります");
define("ERR_EMAIL_EXIST_CHECK"  , "このメールアドレスは登録されています");
define("ERR_MOBILE_EMAIL_CHECK" , "携帯電話のアドレスは登録できません");
define("ERR_AGE_CHECK"          , CHILD_AGE_PREMIUM."歳未満の方は保護者名を入力してください");
define("ERR_AGE_CHECK_AGE_INPUT", CHILD_AGE_PREMIUM."歳未満の方は保護者様の生年月日を入力してください");
define("ERR_AGE_CHECK_AGE"      , CHILD_AGE_PREMIUM."歳以上の方の保護者様を登録して下さい");
define("ERR_PARENT_CHECK"       , "保護者様の情報を登録する場合は全項目入力してください");
define("ERR_EMAIL_NOT_EXIST"    , "このメールアドレスは登録されていません");
define("ERR_AGREE"              , "確認事項に同意して下さい");
define("ERR_AGREE_KIYAKU"       , "利用規約に同意して下さい");
define("ERR_SELECT_PREMIUM"     , "に変更をしたい方を選択して下さい");
define("ERR_SELECT_RANK"        , "P か F を選択して下さい");
define("ERR_CUPON_INVALID"      , "正しいシリアルナンバーではありません。ご確認の上、再度入力をお願い致します。");
define("ERR_CUPON_USED"         , "このシリアルナンバーは既に使用されております。他のシリアルナンバーをご入力ください。");
define("ERR_CUPON_EXPIRED"      , "このシリアルナンバーは有効期限が切れています。他のシリアルナンバーをご入力ください。");
define("NOTICE_COPY_ADDRESS"    , "保護者様の住所情報や電話番号を、お子様の情報にコピーして登録してよいでしょうか。");

define("ERR_PASSWORD_MIN"          , 8);
define("ERR_PASSWORD_MAX"          , 20);
define("ERR_PASSWORD_LETTER"       , "英数字記号 %d文字以上、%d文字以下");
define("ERR_PASSWORD_EQUAL_CHECK"  , "確認用パスワードと異なります");
define("ERR_PASSWORD_CHECK_LEN"    , "正しい文字数のパスワードを入力してください。");
define("ERR_PASSWORD_CHECK_CHAR"   , "パスワードに使用できない文字が含まれています。");
define("ERR_PASSWORD_CHECK_SAME3"  , "同じ文字が３文字連続したパスワードは使用できません。");
define("ERR_PASSWORD_CHECK_EMAIL"  , "e-mailと同じパスワードは使用できません。");
define("ERR_PASSWORD_CHECK_OLD"    , "変更前のパスワードと同一です。");

define("STS_ELSEERROR"          , "エラーが発生しました");
define("STS_NTWERROR"           , "ネットワークエラーが発生しました");
define("STS_SENDERROR"          , "無効なページ遷移です");
define("STS_ACCESSERROR"        , "無効なアクセスです");
define("STS_REGISTERROR"        , "既に登録されているか、無効なアクセスです");
define("STS_PAYMENTERROR"       , "決済システムエラー");
define("STS_PAYMENTERROR_MSG01" , "手続きを続けるにはお手数ですが、登録や更新を再度初めからお願い致します。");
define("STS_PAYMENTERROR_MSG11" , "決済手続きが中止されました。");
define("STS_PAYMENTERROR_MSG21" , "決済手続きがエラーにより中止されました。");

define("STS_ZIPERROR01"         , "ご入力いただきました郵便番号が正しくありません。");
define("STS_ZIPERROR02"         , "ご入力いただきました郵便番号に一致する住所がありません。");
define("STS_ZIPERROR11"         , "郵便番号と住所が一致しません。");
define("STS_ZIPERROR12"         , "郵便番号検索住所 [%s]");
define("STS_ZIPERROR13"         , "ご入力頂いた住所 [%s]");

 
define("STS_SYSTEMERROR"        , "システムエラーが発生しました");



// -------------------------------------------------- Translation
// ショップページの範囲指定選択肢
$GLOBALS['_RADIUS_DEFAULT'] = 50;
$GLOBALS['_RADIUS_UNIT'] = 'km';  // mile or km
$GLOBALS['_RADIUS'] = array(
    '5'     => '5 km',
    '10'    => '10 km',
    '15'    => '15 km',
    '20'    => '20 km',
    '25'    => '25 km',
    '50'    => '50 km',
    '75'    => '75 km',
    '100'   => '100 km',
    '200'   => '200 km',
);
?>
