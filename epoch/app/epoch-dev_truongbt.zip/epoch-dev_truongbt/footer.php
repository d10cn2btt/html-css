<?php if ($pc) : ?>
    <div class="footer">
        <div class="text-center logo">
            <a href="http://sylvanian-families.jp/?page=home" target="_blank">
                <img src="images/logo.png" alt="" class="img-responsive auto lazy">
            </a>
            <div class="footer-socials">
                <ul class="social-icon">
                    <li>
                        <a href="https://www.facebook.com/SylvanianFamilies.jp" target="_blank">
                            <img src="images/footer_icon_1.png" alt="" class="lazy opacity_img">
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com/SF_PHOTO2013" target="_blank">
                            <img src="images/footer_icon_2.png" alt="" class="lazy opacity_img">
                        </a>
                    </li>
                    <li>
                        <a href="https://instagram.com/sylvanianfamilies_official/" target="_blank">
                            <img src="images/footer_icon_3.png" alt="" class="lazy opacity_img">
                        </a>
                    </li>
                </ul>
            </div>
        
        </div>
        <div class="title-footer">
            <div class="text-center footer-policy">
                <strong>| <a href="http://sylvanian-families.jp/support/policy.php" style="font-size: 12px">プライバシーポリシー</a> |</strong>
            </div>
            <div class="text-center project-name"><strong>©EPOCH</strong></div>
        </div>
    </div>
    <div class="totop"></div>
<?php else: ?>
    <div class="footer">
        <div class="line m-line"></div>
        <div class=" ">
            <ul class="m-footer-icons">
                <li>
                    <a href="https://www.facebook.com/SylvanianFamilies.jp" target="_blank">
                        <img src="images/footer_icon_1.png" alt="" class="lazy">
                    </a>
                </li>
                <li>
                    <a href="https://twitter.com/SF_PHOTO2013" target="_blank">
                        <img src="images/footer_icon_2.png" alt="" class="lazy">
                    </a>
                </li>
                <li>
                    <a href="https://instagram.com/sylvanianfamilies_official/" target="_blank">
                        <img src="images/footer_icon_3.png" alt="" class="lazy">
                    </a>
                </li>
            </ul>
            <a href="http://sylvanian-families.jp/?page=home" target="_blank">
                <img src="images/logo.png" alt="" class="img-responsive auto lazy">
            </a>
            
            <div class="title-footer">
                <div class="m-footer-policy text-center">
                    <strong>| <a href="http://sylvanian-families.jp/support/policy.php">プライバシーポリシー</a> |</strong>
                </div>
                <div class="m-project-name text-center"><strong>© EPOCH</strong></div>
            </div>
        </div>
    </div>
    <a href="#to_top_mobile" class="totop_m" style="display: none"></a>
<?php endif; ?>

<script type="text/javascript" src="js/jquery.lazy.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/script_new.js"></script>
</div>
<?php include('includes/analyticstracking.php'); ?>
</body>
</html>