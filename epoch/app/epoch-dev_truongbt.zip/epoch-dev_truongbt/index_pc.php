<div class="bg_header_full">
    <div class="container container_pc">
        <div class="logo_2  col-xs-10 col-xs-offset-1">
            <img src="images/maintop_kitchen.png" alt="" class="img-responsive lazy" style="display:inline-block">
        </div>
    </div>
</div>
<div class="bg_menu_for_pc">
    <div class="link-main">
        <div class="container container_pc">
            <div class="wrap-link-main">
                <div class="container-fluid menu-top">
                    <div class="row">
                        <div class="col-lg-4 col-xs-4 pt10 bordered-right nav_pc">
                            <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/"> <img
                                    src="images/menu_1.png"
                                    alt=""
                                    class="opacity_img img-responsive center-block lazy col-xs-12 delpadding "></a>
                        </div>
                        <div class="col-lg-4 col-xs-4 pt10 bordered-right nav_pc">
                            <a href="http://sylvanian-families.jp/shop/kitchen/laketown/">
                                <img src="images/menu_2.png" alt=""
                                     class="opacity_img img-responsive center-block lazy col-xs-12 delpadding "></a>
                        </div>
                        <div class="col-lg-4 col-xs-4 pt10 nav_pc">
                            <a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/"> <img
                                    src="images/menu_3.png"
                                    alt=""
                                    class="opacity_img img-responsive center-block lazy col-xs-12 delpadding "></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!--start slice-->

<div class="content-canvas bg_content-canvas ">
    <div class="container container_pc">
        <div class="">
            <!-- Top slider -->
            <div id="carousel-example-generic" class="wow fadeIn carousel slide container_buffer" data-ride="carousel">
                <ol class="carousel-indicators carousel-indicators_mobile">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
                </ol>
                <div class="clear_both"></div>

                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <img src="images/bg-slide_2.jpg" alt="シルバニア森のキッチンはシルバニアファミリーの仲間たちと会える楽しいレストランです！"
                             class="lazy img_nivoslide">
                    </div>
                    <div class="item ">
                        <img src="images/bg-slide_1.png" alt="バースデープランで特別な思い出を作りましょう！"
                             class="lazy img_nivoslide ">
                    </div>

                    <div class="item">
                        <img src="images/bg-slide_3.jpg" alt="家族みんなが大満足の大人気ブッフェ！" class="lazy img_nivoslide ">
                    </div>
                    <div class="item">
                        <img src="images/bg-slide_4.jpg" alt="シルバニア森のキッチンではショコラウサギシェフが出迎えてくれます！"
                             class="lazy img_nivoslide ">
                    </div>
                </div>
                <!-- Controls -->
                <a class="left carousel-control " href="#carousel-example-generic" role="button"
                   data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left bg_nav_slide_left" aria-hidden="true">
                </span>
                    <span class="sr-only">Previous</span>
                </a>

                <a class="right carousel-control " href="#carousel-example-generic" role="button"
                   data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right bg_nav_slide_right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>

            </div>
        </div>
    </div>
</div>

<div class="">
    <div class="container container_pc ptb20 fix_padding_1366" id="bottom">
        <div class="col-xs-2 right  col-xs-offset-1 right ">
            <img src="images/flower_left.png" alt="" class="lazy img-responsive flower_right">
        </div>
        <div class="col-xs-6 center delpadding">
            <img src="images/text_1.png" alt="" class="img-responsive lazy center-block">
        </div>
        <div class="col-xs-2 ">
            <img src="images/flower_right.png" alt="" class="lazy img-responsive flower_left">
        </div>
    </div>
</div>

<!--content for PC-->
<div class="overflow_hi">
    <div class="container-fluid delpadding ">
        <div class="row container_block_4_img mb15 add_margin_1920">
            <div class=" container container_pc">
                <div class=" container_buffer">
                    <div class="col-xs-6 col-md-6 grid-service delpadding_right_for_block delpadding_left">
                        <div class="block-buffer fleft">
                            <div class="col-lg-12 col-xs-12 col-sm-12 col-md-12 delpadding">
                                <div class="bg_white bg_white_1">
                                    <img src="images/pc_text_block_1.png" alt="" class="text-header img-responsive">
                                </div>
                            </div>
                            <div class="block-buffer_child_1 nopadding_1920">
                                <div class="col-md-12">
                                    <div class="child_img_second">
                                            <span class="span_hidden fleft">
                                                <img src="images/buffer_container_1_1.jpg"
                                                     alt="シルバニア村の仲間たちの楽しいステージショー！"
                                                     class="img-responsive fleft width_50 width_1920 lazy">
                                            </span>
                                            <span class="span_hidden fright">
                                                <img src="images/buffer_container_1_2.jpg"
                                                     alt="シルバニア村の仲間たちと一緒に写真撮影！"
                                                     class="img-responsive fright width_50 width_1920 lazy">
                                            </span>
                                    </div>
                                    <div class="clear_both"></div>
                                        <span class="span_block_2 mt20">
                                             <img src="images/buffer_container_1_3.jpg"
                                                  alt="シルバニア村の仲間たちと握手をしたり触れ合いましょう！"
                                                  class="img-responsive auto  full k2 lazy">
                                            </span>
                                    <div id="fix_ie_1" class="buffer_fooer fix_height_12">
                                        シルバニアファミリーのなかまがお席まで遊びに来ます！<br/>
                                        あくしゅをしたり、写真をとったり、なかよしくしてくださいね。<br/>
                                        店内には人形や小物がたくさん！見ているだけでワクワクしてきます。
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-6 grid-service delpadding_left_for_block delpadding_right">
                        <div class="block-buffer  fright ">
                            <div class="col-lg-12 col-xs-12 col-sm-12 col-md-12 delpadding pos_block_2">
                                <div class="bg_white bg_white_2">
                                    <div class="pc_width60 pc_width">
                                        <img src="images/pc_text_block_2.png" alt=""
                                             class="text-header text-header-2 img-responsive">
                                    </div>
                                    <div class="pc_width40 pc_width">
                                        <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/birthday.php">
                                            <img src="images/white_2_1.png" alt="" class="img-responsive opacity_img">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="clear_both"></div>
                            <div class="block-buffer_child_1 nopadding_1920">
                                <div class="col-md-12">
                                    <div class="child_img_second">
                                            <span class="span_hidden fleft">
                                                <img src="images/buffer_container_2_1.jpg"
                                                     alt="バースデープランのショコラウサギシェフ特製の特別なケーキ！"
                                                     class="img-responsive fleft width_50 width_1920 lazy"></span>
                                            <span class="span_hidden fright"><img
                                                    src="images/buffer_container_2_2.jpg"
                                                    alt="バースデープランでもらえる記念写真と特別なプレゼント！"
                                                    class="lazy img-responsive fright width_50 width_1920"></span>
                                    </div>
                                    <div class="clear_both"></div>
                                        <span class="span_block_2 mt20">
                                        <img src="images/buffer_container_2_3.jpg"
                                             alt="誕生日はシルバニア村の仲間たちに祝ってもらいましょう！"
                                             class="img-responsive auto full k2 lazy">
                                        </span>
                                    <div id="fix_ie_2" class="buffer_fooer fix_height_12">
                                        シルバニアファミリーのなかまがお祝いしてくれるバースデープランをご用意しています。<br/>
                                        ケーキのろうそくを吹き消したあとは、プレゼントをもらって記念撮影。<br/>
                                        大切な記念日をシルバニアファミリーのなかまと楽しくすごしましょう！
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clear_both"></div>
                <div class=" container_buffer mt24">
                    <div class="col-xs-6 col-md-6 grid-service delpadding_right_for_block delpadding_left">
                        <div class="block-buffer fleft">
                            <div class="col-lg-12 col-xs-12 col-sm-12 col-md-12">
                                <div class="bg_white bg_white_3">
                                    <img src="images/pc_text_block_3.png" alt=""
                                         class="text-header text-header-3 img-responsive">
                                </div>
                            </div>
                            <div class="block-buffer_child_1 nopadding_1920">
                                <div class="col-md-12">
                                    <div class="child_img_second">
                                            <span class="span_hidden fleft"><img
                                                    src="images/buffer_container_3_1.jpg"
                                                    alt="いろいろな種類のお料理が楽しめる大人気のブッフェ！"
                                                    class="lazy img-responsive fleft width_50 width_1920"></span>
                                           <span class="span_hidden fright">
                                               <img src="images/buffer_container_3_2.jpg"
                                                    alt="家族みんなで好きなお料理をお腹いっぱい食べましょう！"
                                                    class="lazy img-responsive fright width_50 width_1920" style="    border-radius: 4px;}">
                                           </span>
                                    </div>
                                    <div class="clear_both"></div>
                                        <span class="span_block_2 mt20">
                                        <img src="images/buffer_container_3_3.jpg"
                                             alt="ショコラウサギシェフのおいしい料理をおなかいっぱい楽しめます！"
                                             class="img-responsive auto full k2 lazy">
                                        </span>
                                    <div id="fix_ie_3" class="buffer_fooer fix_height_34">
                                        ショコラウサギシェフのおいしい料理をおなかいっぱい楽しめるブッフェ形式です。<br/>
                                        自分たちで作れるわたがしはお子様たちに大人気！
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-6 col-md-6  grid-service delpadding_left_for_block delpadding_right">
                        <div class="block-buffer  fright ">
                            <div class="col-lg-12 col-xs-12 col-sm-12 col-md-12 delpadding ">
                                <div class="bg_white bg_white_4">
                                    <img src="images/pc_text_block_4.png" alt=""
                                         class="text-header text-header-4 img-responsive">
                                </div>
                            </div>
                            <div class="clear_both"></div>
                            <div class="block-buffer_child_1 nopadding_1920">
                                <div class="col-md-12">
                                    <div class="child_img_second">
                                            <span class="span_hidden fleft"><img
                                                    src="images/buffer_container_4_1.jpg"
                                                    alt="シルバニアファミリーの大きなジオラマを展示しています！"
                                                    class="lazy img-responsive fleft width_50 width_1920"></span>
                                           <span class="span_hidden fright"> <img
                                                   src="images/buffer_container_4_2.jpg"
                                                   alt="シルバニアファミリーの雑貨や海外で販売されている商品も販売しています！"
                                                   class="lazy img-responsive fright width_50 width_1920"></span>
                                    </div>
                                    <div class="clear_both"></div>
                                        <span class="span_block_2 mt20">
                                        <img src="images/buffer_container_4_3.jpg"
                                             alt="シルバニアファミリーの特別なアイテムがたくさんのシルバニア森のキッチン！"
                                             class="img-responsive auto full k2 lazy">
                                        </span>
                                    <div id="fix_ie_4" class="buffer_fooer fix_height_34">
                                        シルバニアファミリーの雑貨や海外で販売されている商品など特別なアイテムがたくさん。<br/>
                                        大きなジオラマも展示しています。
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end block 4 imgaes-->
    <div class="">
        <div class="container container_pc">
            <div class="warrap_flower_1">
                <div class="flower_12 ">&nbsp;</div>
                <div class="btn_main">
                    <a href="http://sylvanian-families.jp/fanclub/info/members_card.php" target="_blank">
                        <img src="images/banner-fanclub-membercard.png"
                             alt="シルバニアファミリーのお店で割引価格でお買い物ができるプレミアム会員メンバーズカードの特典はこちらから！"
                             class="opacity_img slogan_ads_2 lazy img-responsive auto">
                    </a>
                </div>
                <div class="flower_12">&nbsp;</div>
            </div>
            <div class="warrap_flower_1 mb30">
                <div class="flower_12 ">
                    <img src="images/f_1.png" alt="" class="img-responsive flower_first">
                </div>
                <div class="btn_main">
                    <a href="http://sylvanian-families.jp/play/kitchen/" target="_blank">
                        <img src="images/image_flower.png"
                             alt="シルバニア森のキッチンのシェフがショコラウサギのお父さんになったよ！森のキッチンミニストーリーはこちら！"
                             class="opacity_img slogan_ads_2 lazy img-responsive auto">
                    </a>
                </div>
                <div class="flower_12">
                    <img src="images/f_2.png" alt="" class="img-responsive flower_second">
                </div>
            </div>
        </div>
        <div class="line "></div>
        <div class="container container_pc">
            <div class="row">
                <div class=" col-xs-8 col-xs-offset-2 delpadding">
                    <div class="slogan_ads_1">

                        <img src="images/slogan-bottom.png" alt="" class="opacity_img auto img-responsive lazy">
                    </div>
                </div>
                <div class="wrap_img_container_5">
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 ">
                        <div class="img_store">
                            <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/" class="a_img_store">
                                <img src="images/buffer_container_5_1.jpg"
                                     alt="シルバニア森のキッチン　横浜ワールドポーター店の店舗情報はこちら！"
                                     class="img_container_5  img-responsive lazy">
                            </a>
                            <a href="http://sylvanian-families.jp/shop/kitchen/yokohama_wp/">
                                <div class="text_img text_img_first">
                                    <img src="images/text_img.png" alt="" class="col-xs-12 img-responsive img_1">
                                    <img src="images/text_img_btn.png" alt="" class="col-xs-12 img-responsive img_2">
                                </div>

                            </a>
                        </div>
                    </div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 ">
                        <div class="img_store">
                            <a href="http://sylvanian-families.jp/shop/kitchen/laketown/" class="a_img_store">
                                <img src="images/buffer_container_5_2.jpg"
                                     alt="シルバニア森のキッチン　レイクタウンアウトレット店の店舗情報はこちら！"
                                     class="img_container_5 img-responsive lazy">
                            </a>
                            <a href="http://sylvanian-families.jp/shop/kitchen/laketown/">
                                <div class="text_img">
                                    <img src="images/text_img_1.png" alt="" class="col-xs-12 img-responsive img_1">
                                    <img src="images/text_img_btn.png" alt="" class="col-xs-12 img-responsive img_2">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                        <div class="img_store">
                            <a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/" class="a_img_store">
                                <img src="images/buffer_container_5_3.jpg"
                                     alt="シルバニア森のキッチン　ららぽーとTOKYO-BAY店の店舗情報はこちら！"
                                     class="img_container_5 lazy img-responsive">
                            </a>
                            <a href="http://sylvanian-families.jp/shop/kitchen/llp_tokyobay/">
                                <div class="text_img">
                                    <img src="images/text_img_2.png" alt="" class="col-xs-12 img-responsive img_1">
                                    <img src="images/text_img_btn.png" alt="" class="col-xs-12 img-responsive img_2">
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="line"></div>
    <div class="logo-footer footer">
        <div class="center logo footer_social">
            <a href="http://sylvanian-families.jp/?page=home" target="_blank">
                <img src="images/logo.png" alt="" class="img-responsive auto lazy fix_logo_xs">
            </a>
            <div class="fix_link_footer">
                <ul class="icon_footer">
                    <li>
                        <a href="https://www.facebook.com/SylvanianFamilies.jp" target="_blank">
                            <img src="images/footer_icon_1.png" alt="" class="lazy opacity_img">
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com/SF_PHOTO2013" target="_blank">
                            <img src="images/footer_icon_2.png" alt="" class="lazy opacity_img">
                        </a>
                    </li>
                    <li>
                        <a href="https://instagram.com/sylvanianfamilies_official/" target="_blank">
                            <img src="images/footer_icon_3.png" alt="" class="lazy opacity_img">
                        </a>
                    </li>
                </ul>
            </div>

        </div>
        <div class="title-footer">
            <div class="tf-1 center bold footer-menu">
                | <a href="http://sylvanian-families.jp/support/policy.php" style="font-size: 12px">プライバシーポリシー</a> |
            </div>
            <div class="tf-1 center bold lest_spac">©EPOCH</div>
        </div>
    </div>
</div>
<div class="totop"></div>